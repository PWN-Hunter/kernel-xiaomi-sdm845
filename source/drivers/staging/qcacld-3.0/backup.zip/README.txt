This is CNSS WLAN Host Driver for products starting from iHelium
